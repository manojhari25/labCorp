import { Injectable } from '@angular/core';
@Injectable()
export class TemperatureMonitor {
    public currentaddTemperatures: Array<any> = [];
    public checkTemp: Array<any> = [];
    
    /**
     * @method: recordTemperature
     * @param: temp 
     * @description: To store the temperatures in currentaddTemperatures array.
     */
    public recordTemperature(temp): void {
      temp && this.currentaddTemperatures.length < 8 ? this.currentaddTemperatures.push(temp) : '';
    }
    
    /**
     * @method: getCurrentMedian      
     * @description: It returns median value.
     */
     
    public getCurrentMedian(){
      const median = null;
      const templength = this.currentaddTemperatures.length;
      this.currentaddTemperatures.sort();
      this.checkTemp= this.currentaddTemperatures.map((value) => { return Number(value)});
      if (templength % 2 === 0) {
        median = (this.checkTemp[templength / 2 - 1] + this.checkTemp[templength / 2]) / 2;
      } else {
       median = this.checkTemp[(templength - 1) / 2];
      }
      return median;
    }
    
    /**
     * @method: getTotalTemperatures      
     * @description: It returns total temperatures length.
     */
    public getTotalTemperatures(){
      return this.currentaddTemperatures.length;
    }
    
    
    /**
     * @method: clearTempList      
     * @description: clear the temperatures.
     */
     
    public clearTempList(): void {
      this.currentaddTemperatures.length=0;
    }
}