import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { TemperatureMonitor } from './TemperatureMonitor.service';


describe('Temperature service', () => {
    let tempservice: TemperatureMonitor;
    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [TemperatureMonitor]
      });

      tempservice = TestBed.get(TemperatureMonitor);
      tempservice.recordTemperature(7);
      tempservice.recordTemperature(5);
      tempservice.recordTemperature(2);
    });

    it('should create an instance', () => {
      expect(tempservice).toBeDefined();
    });
    
     it('record temperature values', () => {
      expect(tempservice.getTotalTemperatures()).toEqual(3);
    });
    
    it('Get Current Median', () => {
      expect(tempservice.getCurrentMedian()).toEqual(5);
    });
    
    it('clear Temperature Values',()=>{
     tempservice.clearTempList();
     expect(tempservice.currentaddTemperatures.length).toEqual(0);
    });
    
    it('record max 8 temperatures', () => {
      tempservice.recordTemperature(6);
      tempservice.recordTemperature(6);
      tempservice.recordTemperature(8);
      tempservice.recordTemperature(5);
      tempservice.recordTemperature(4);
      tempservice.recordTemperature(1);
      expect(tempservice.getTotalTemperatures()).toEqual(8);
      
    });
    
    
    
    
  });