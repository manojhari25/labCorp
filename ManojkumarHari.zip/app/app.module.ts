import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { TemperatureMonitor } from './services/TemperatureMonitor.service';
import { AppComponent } from './app.component';


@NgModule({
  declarations: [
    AppComponent 
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [TemperatureMonitor],
  bootstrap: [AppComponent]
})
export class AppModule { }
