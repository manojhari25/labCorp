import { Component, Input , HostListener } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { TemperatureMonitor } from './services/TemperatureMonitor.service';

@Component({
  selector: 'app-root',
  templateUrl: './app/app.component.html',
  styleUrls: ['./app/app.component.css']
})
export class AppComponent {
 @Input('progress') progressbarValues;
 math = window.Math;
 public disabeAddButton: number = 0;
 public disableClearBtn: boolean = false;
 public disablegetMedianBtn: boolean = false;
 public NumberOnly:boolean = false;
 public showListTemp:boolean = false;
 public fieldRequired:boolen = false;
 public showProgress :boolean = false;
 public maxvalues: number = 8;
 public progressbarValues: number = 0;
 
 
 constructor(private temperatureService:TemperatureMonitor,
 private fb: FormBuilder){
 }
 
 title = 'app works!';
 
  ngOnInit(): void {
    this.buildForm();
  }
  
  /**
     * @method: buildForm      
     * @description: Instance of tempMonitorForm.
  */
  
  buildForm(): void {
    this.tempMonitorForm = this.fb.group({
      'temperature': [this.temperature, [
          Validators.required
        ]
      ]
    });
  }
  
  /**
     * @method: IsNumber      
     * @description: Validation for number only.
  */
  public IsNumber(event){
    if (event.which < 48 || event.which > 57){
        if(event.which !== 46 && event.which !== 95 && event.which !== 45 && event.which !== 13){
           event.preventDefault();
           this.NumberOnly = true;
          return false;
        }
    }else{
      this.NumberOnly = false;
      return true;
    }
  }
  
  /**
     * @method: submitTemperatures      
     * @description: It returns temperatures values.
  */
     
 public submitTemperatures(): void{
   this.showProgress = true;
   this.showListTemp = true;
   if(!this.temperature){
     this.fieldRequired = true;
     this.showProgress = false;
     this.showListTemp = false;
   }else{
    this.disablegetMedianBtn = true;
     this.fieldRequired = false;
     this.temperatureService.recordTemperature(this.temperature);
     this.progressBar();
     this.tempMonitorForm.reset();
   }
 }

  
  /**
     * @method: calculateMedianTemp      
     * @description: calculates the median temperature.
  */
  public calculateMedianTemp(): void{
    this.currentmedianValue = this.temperatureService.getCurrentMedian();
    this.disablegetMedianBtn = false;
    this.progressBar();
  }
  
  /**
     * @method: progressBar      
     * @description: calculates the temepartures ans show values.
  */
  public progressBar(): void {
    this.addedtemperatures = this.temperatureService.currentaddTemperatures;
    this.disabeAddButton = this.temperatureService.getTotalTemperatures(); 
    this.progressbarValues = (this.disabeAddButton/ this.maxvalues)*100;
    if(this.disabeAddButton > 0){
      this.disableClearBtn = true;
    }else{
      this.disableClearBtn = false;
    }
  }
  
    /**
     * @method: clearList      
     * @description: clear the values.
  */
  public clearList(): void {
    this.temperatureService.clearTempList();
    this.showProgress = false;
    this.disablegetMedianBtn = false;
    this.currentmedianValue = null;
    this.progressBar();
    this.temperature = null;
    this.showListTemp = false;
  }
 
  
}
