import { TestBed, async } from '@angular/core/testing';
import { ReactiveFormsModule,  FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { TemperatureMonitor } from './services/TemperatureMonitor.service';

describe('AppComponent', () => {
  let temperatureStub,
  tempfixture:ComponentFixture<AppComponent>,
  component:AppComponent;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[ReactiveFormsModule, FormsModule],
      declarations: [
        AppComponent
      ],
      providers: [TemperatureMonitor]
    }).compileComponents().then(()=>{
      tempfixture = TestBed.createComponent(AppComponent);
      component = tempfixture.debugElement.componentInstance;
      temperatureStub=tempfixture.debugElement.injector.get(TemperatureMonitor);
    });
  }));
  
  
  
 it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
    expect(app.title).toEqual('app works!');
  }));

  it('should render title in a h1 tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('app works!');
    
  }));
  
  it('Form invalid when on empty data', () => {
    component.buildForm();
    expect(component.tempMonitorForm.valid).toBeFalsy();
  }); 
  
  it('temperature updates', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    component.buildForm();
    component.tempMonitorForm.controls['temperature'].setValue(5);
    expect(component.tempMonitorForm.value).toEqual({temperature: 5});
    expect(component.tempMonitorForm.valid).toBeTruthy();
  }));
  
  it(`Initilizing the temperature Values `, () => {
    expect(component.currentmedianValue).not.toBeDefined();
    expect(component.temperature).not.toBeDefined();
    expect(component.disablegetMedianBtn).toBeFalsy();
    expect(component.ShowProgressBar).toBeFalsy();
  });
  
   it('Record the temperature', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    component.buildForm();
    component.temperature = 20;
    spyOn(component.temperatureService,'recordTemperature');
    component.submitTemperatures();
    expect(component.temperatureService.recordTemperature).toHaveBeenCalledWith(20);
  }));
  
  it('Should clear recorded temperatures', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    spyOn(component.temperatureService,'clearTempList');
    component.clearList();
    expect(component.temperatureService.clearTempList).toHaveBeenCalled();
    expect(component.currentmedianValue).toBe(null);
    expect(component.disablegetMedianBtn).toBeFalsy();
    
  }));
  
   it("checking progress values", () => {
    temperatureStub.temperatures = [-7, 1, 3, 5, 7, 8, 9];
    spyOn(temperatureStub,"getTotalTemperatures").and.returnValue(7);
    component.progressBar();
    tempfixture.detectChanges();
    expect(component.disabeAddButton).toBe(7);
    expect(temperatureStub.getTotalTemperatures).toHaveBeenCalled();
  });
  
  
  
  it(`should call calculateMedianTemp`, () => {
    spyOn(temperatureStub,"getCurrentMedian").and.returnValue(2);
    component.calculateMedianTemp();
    expect(temperatureStub.getCurrentMedian).toHaveBeenCalled();
     expect(component.currentmedianValue).toBe(2);
   });

  
});
